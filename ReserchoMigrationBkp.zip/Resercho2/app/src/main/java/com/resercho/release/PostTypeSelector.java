package com.resercho.release;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.resercho.release.R;

public class PostTypeSelector extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_type_selector);
    }
}
