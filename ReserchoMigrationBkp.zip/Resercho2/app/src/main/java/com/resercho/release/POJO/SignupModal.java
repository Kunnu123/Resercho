package com.resercho.release.POJO;

public class SignupModal {

    String fullname, mobile,email, birthday, gender, username, password;

    public SignupModal() {
    }

    public SignupModal(String fullname, String mobile, String email, String birthday, String gender, String username, String password) {
        this.fullname = fullname;
        this.mobile = mobile;
        this.email = email;
        this.birthday = birthday;
        this.gender = gender;
        this.username = username;
        this.password = password;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
