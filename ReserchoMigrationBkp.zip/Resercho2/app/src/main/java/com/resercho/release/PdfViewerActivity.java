package com.resercho.release;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.resercho.release.R;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


import com.github.barteksc.pdfviewer.PDFView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class PdfViewerActivity extends AppCompatActivity {

    PDFView pdfView;
    String path, pid,ownerid;
    FloatingActionButton downFab;
    boolean download = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        try{
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Your Work");
        }catch (Exception e){

        }

        path = getIntent().getStringExtra("path");
        pid = getIntent().getStringExtra("pid");
        ownerid = getIntent().getStringExtra("owner");

        pdfView = findViewById(R.id.pdfView);
        downFab = findViewById(R.id.downFab);

        if(download){
            downFab.show();
            downFab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sendDownload(pid,ownerid);
                }
            });
        }else{
            downFab.hide();
        }


        if(path==null)
            path = "/sdcard/download/Pdfdocsample.pdf";



        try {
            Uri uri = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.APPLICATION_ID + ".provider", new File(path));
            pdfView.fromUri(uri).load();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Under Development",Toast.LENGTH_LONG).show();
        }
    }

    public boolean checkForStoragePermissions(){
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
            return true;
        else
            return false;
    }

    public void askForStoragePermission(){
        ActivityCompat.requestPermissions(PdfViewerActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE},101);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 101 && grantResults[0]==RESULT_OK){

        }else{
            Toast.makeText(getApplicationContext(),"We need permission to save this document on your device",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }


    protected void toastOnMain(final String msg){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
            }
        });
    }


    protected void sendDownload(final String pid, final String ownerid){
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                NetworkHandler.sendDownload(PdfViewerActivity.this, ownerid, pid, new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Log.d("Downin","Downin onFailure:"+e);
                        toastOnMain("There was problem downloading file: "+e);
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        String resp = response.body().string();
                        Log.d("Downin","Downin onFailure:"+resp);
                        try{
                            JSONObject object = new JSONObject(resp);
                            if(object.getInt("success")==1){
                                toastOnMain("Download acknowledged");
                                downfileInit();
                            }else{
                                toastOnMain("Download not acknowledged");
                            }
                        }catch (JSONException e){
                            toastOnMain("There was problem downloading file : "+e);
                        }
                    }
                });
            }
        });

        thread.start();
    }


    protected void downfileInit(){
        String mime = UtilityMethods.getMimeFromUrl(path);
        if (mime != null && (mime.equalsIgnoreCase("png") || mime.equalsIgnoreCase("jpeg") || mime.equalsIgnoreCase("mp4")
                || mime.equalsIgnoreCase("jpg") || mime.equalsIgnoreCase("mp3") || mime.equalsIgnoreCase("pdf") || mime.equalsIgnoreCase("avi"))) {

            File f = new File(Environment.getExternalStorageDirectory() + File.separator + "DOWNLOAD_"+DataHandler.getUserId(getApplicationContext())+System.currentTimeMillis()+"."+mime);
            File folder = new File(Environment.getExternalStorageDirectory() +
                    File.separator + "Resercho");
            boolean success = true;
            if (!folder.exists()) {
                success = folder.mkdirs();
            }
            if (success) {
                f = new File(Environment.getExternalStorageDirectory()+File.separator + folder.getName() + File.separator + "DOWNLOAD_"+DataHandler.getUserId(getApplicationContext())+System.currentTimeMillis()+"."+mime);
            } else {
                // Do something else on failure
            }


            downloadFile(path,f);
        }else{
            Toast.makeText(getApplicationContext(),"File not downloadable",Toast.LENGTH_LONG).show();
        }

    }

    private void downloadFile(final String url, final File outputFile) {


        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                downLoadOnThread(url,outputFile);
            }
        });

        thread.start();

    }


    protected void downLoadOnThread(String url, File outputFile){
        try {
            URL u = new URL(url);
            URLConnection conn = u.openConnection();
            int contentLength = conn.getContentLength();

            DataInputStream stream = new DataInputStream(u.openStream());

            byte[] buffer = new byte[contentLength];
            stream.readFully(buffer);
            stream.close();

            DataOutputStream fos = new DataOutputStream(new FileOutputStream(outputFile));
            fos.write(buffer);
            fos.flush();
            fos.close();
            toastOnMain("File should have been downloaded");
        } catch(FileNotFoundException e) {
            toastOnMain("File could not be downloaded");
            return; // swallow a 404
        } catch (IOException e) {
            toastOnMain("File could not be downloaded");
            return; // swallow a 404
        }
    }


}
