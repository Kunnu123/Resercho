package com.resercho.release;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import com.resercho.release.R;
import android.widget.ProgressBar;

import com.resercho.release.Adapters.AdapterGroup;
import com.resercho.release.POJO.ModelGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class JoinedGroupActivity extends AppCompatActivity {


    // Work
    RecyclerView recycler;
    AdapterGroup adapter;
    List<ModelGroup> list;

    ProgressBar pbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joined_group);

        pbar = findViewById(R.id.pbar);
        recycler = findViewById(R.id.joinedGRv);
        try{
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("My Groups");

        }catch (Exception e){

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadGroupData();
    }

    protected void hidePbar(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                pbar.setVisibility(View.GONE);
            }
        });
    }

    protected void showNoJoined(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                findViewById(R.id.noGroupMsg).setVisibility(View.VISIBLE);
            }
        });
    }

    protected void showPbar(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                pbar.setVisibility(View.VISIBLE);
            }
        });
    }

    protected void loadGroupData(){
        Log.d("Resercho","Jgin loadGroupData()");
        showPbar();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                NetworkHandler.fetchJoinedGroups(JoinedGroupActivity.this,new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Log.d("Resercho","HomeFrag : Jgin onFailure::"+e);
                        hidePbar();
                        loadGroupData();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        String resp = response.body().string();
                        Log.d("Resercho","HomeFrag : Jgin onResponse:"+resp);
                        parseJson(resp);
                    }
                });
            }
        });
        thread.start();
    }

    protected void parseJson(String json){

        list = new ArrayList<>();
        try{
            JSONObject jsonObject =new JSONObject(json);
            if(jsonObject.getInt("success")==1){
                JSONArray arr = jsonObject.getJSONArray("data");
                for(int i=0;i<arr.length();i++){
//                    ModelJoinedGroups w = ConverterJson.parseJoinedGroupJson(arr.getJSONObject(i));
                    ModelGroup w = ConverterJson.parseGroupJson(arr.getJSONObject(i));
                    if(w!=null) {
                        list.add(w);
                    }
                    else
                        Log.d("Resercho","HomeFrag Jgin : Null Model : "+i);
                }

                showWorkRecycler(list);
            }else{
                showNoJoined();
                Log.d("Resercho","HomeFrag : Jgin Request Success:"+jsonObject.getInt("success"));
            }
        }catch (JSONException e){

        }

        hidePbar();
    }


    protected void showWorkRecycler(final List<ModelGroup> list){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                RecyclerView.LayoutManager layman = new LinearLayoutManager(JoinedGroupActivity.this,LinearLayoutManager.VERTICAL,true);
                adapter = new AdapterGroup(JoinedGroupActivity.this,list);
                adapter.setJoined(true);
                recycler.setLayoutManager(layman);
                recycler.setAdapter(adapter);
            }
        });
        Log.d("Resercho","Dashboard Work Jgin showRv : "+list.size());

    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
