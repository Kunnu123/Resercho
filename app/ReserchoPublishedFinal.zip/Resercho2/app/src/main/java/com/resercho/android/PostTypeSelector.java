package com.resercho.android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.resercho.android.R;

public class PostTypeSelector extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_type_selector);
    }
}
